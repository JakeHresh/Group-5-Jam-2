﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class NewBehaviourScript : MonoBehaviour
{
    public Rigidbody sunProjectile;
    public float speed = 10;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Rigidbody instantiatedSunProjectile = Instantiate(sunProjectile,
                                                                transform.position,
                                                                transform.rotation)
                                                                as Rigidbody;

            instantiatedSunProjectile.velocity = transform.TransformDirection(new Vector3(0, 0, speed));
        }
    }
}
